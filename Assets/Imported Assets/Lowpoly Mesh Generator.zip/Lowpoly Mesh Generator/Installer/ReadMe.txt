Folder contains 3 packages of the "Lowpoly Mesh Generator" asset designed for 3 different Unity render pipelines.

Based on a project’s render pipeline import only one of the included packages.


-------------------------------------------------------------------
Asset forum:            https://forum.unity.com/threads/low-poly-mesh-generator.395255/
Support and bug report: support@amazingassets.world